"""Valida o motor contra os casos praticos 02 a 07 do material do curso."""
from motor_reforma import *

OK, FALHAS = [], []


def chk(rotulo, obtido, esperado, tol=0.02):
    dif = obtido - esperado
    pct = abs(dif) / esperado * 100 if esperado else 0
    ok = abs(dif) <= max(tol, abs(esperado) * 0.0005)
    (OK if ok else FALHAS).append(rotulo)
    print(f"  {'OK ' if ok else 'DIF'} {rotulo:<44} "
          f"motor {obtido:>14,.2f} | slide {esperado:>14,.2f} | {pct:>6.3f}%")


print("=" * 100)
print("CASO 02 - MARK UP MULTIPLICADOR (slides 39 a 42)")
print("=" * 100)

p26 = Parametros(ano=2026, aliq_icms=0.12, pis=0.0165, cofins=0.076)
r = motor_custo(500.0, 0.0986, 0.10, p26)
print(" 2026 (PIS/COFINS nao cumulativos, ICMS fora da base):")
chk("Preco antes dos tributos", r["preco_antes_tributos"], 623.91)
chk("Valor total da NF", r["nf"], 781.25)
chk("ICMS", r["icms_iss"], 93.75)
chk("PIS", r["pis"], 11.34)
chk("COFINS", r["cofins"], 52.25)

p27 = Parametros(ano=2027, aliq_icms=0.12, modelo_base="professor")
r = motor_custo(500.0, 0.0986, 0.10, p27)
print("\n 2027 - modelo do professor:")
chk("Valor total da NF", r["nf"], 781.68)
chk("Base de calculo CBS/IBS", r["bc_cbs_ibs"], 687.88)
chk("ICMS", r["icms_iss"], 93.80)
chk("CBS 9,2%", r["cbs"], 63.29)
chk("IBS 0,1%", r["ibs"], 0.69)

print("\n 2027 - modelos alternativos (mesma entrada, premissa diferente):")
for m in ("professor", "lc214", "plp16"):
    rr = motor_custo(500.0, 0.0986, 0.10,
                     Parametros(ano=2027, aliq_icms=0.12, modelo_base=m))
    print(f"   {m:<11} NF R$ {rr['nf']:>8,.2f} | markup {rr['markup_total']:.4f}")


print("\n" + "=" * 100)
print("CASO 03 - SIMPLES NACIONAL TRADICIONAL x HIBRIDO (slides 46 a 51)")
print("=" * 100)

rep = RepartDAS(irpj=0.00517, csll=0.00329, cofins=0.01198, pis=0.00260,
                cpp=0.03949, ipi=0.0, icms=0.03150, iss=0.0)
ps = Parametros(ano=2027)
s = motor_simples(1_000_000, rep, 600_000, 90_000, ps)
chk("DAS tradicional (9,403%)", s["tradicional"]["das"], 94_030.00)
chk("Liquido tradicional", s["tradicional"]["liquido"], 905_970.00)
chk("Creditos de CBS e IBS", s["creditos"], 64_170.00)
chk("Preco hibrido sem CBS/IBS", s["hibrido"]["preco_sem_cbs_ibs"], 914_453.32)
chk("DAS hibrido (7,945%)", s["hibrido"]["das"], 72_653.32)
chk("BC da CBS/IBS hibrido", s["hibrido"]["bc_cbs_ibs"], 849_536.28)
chk("CBS devida", s["hibrido"]["cbs_devida"], 78_157.34)
chk("CBS a recolher", s["hibrido"]["cbs_recolher"], 14_677.34)
chk("IBS a recolher", s["hibrido"]["ibs_recolher"], 159.54)
chk("Valor total da NF hibrido", s["hibrido"]["nf"], 993_460.19)
chk("Carga hibrida total", s["hibrido"]["carga"], 87_490.19)
chk("Reducao de carga", s["delta_carga"], 6_539.81)
print(f"  ... Credito de equilibrio (ponto de virada): "
      f"R$ {s['credito_equilibrio']:,.2f} de base de compras")

print("\n Cenario do slide 53 (menos creditos, carga AUMENTA):")
s2 = motor_simples(1_000_000, rep, 590_000, 0, ps)
chk("Preco hibrido sem CBS/IBS", s2["hibrido"]["preco_sem_cbs_ibs"], 924_555.97)
chk("Valor total da NF", s2["hibrido"]["nf"], 1_004_435.69)
chk("CBS a recolher", s2["hibrido"]["cbs_recolher"], 24_740.80)
chk("Aumento de carga", -s2["delta_carga"], 4_435.69)


print("\n" + "=" * 100)
print("CASO 04 - LUCRO PRESUMIDO, CLINICA MEDICA (slides 55 a 59)")
print("=" * 100)

g4 = [Gasto("Despesas", 240_000, "integral"),
      Gasto("Medicos PJ", 900_000, "red60"),
      Gasto("Materiais medicos", 360_000, "red60"),
      Gasto("Aluguel", 120_000, "red70"),
      Gasto("Folha CLT", 720_000, "sem")]
p4 = Parametros(ano=2027, aliq_icms=0.0, aliq_iss=0.03, reducao_saida="red60")
r4 = motor_preco_2026(3_100_000, g4, p4)
cr = r4["creditos"]
chk("Credito de CBS", cr["cbs"], 68_165.05)
chk("Credito de IBS", cr["ibs"], 779.55)
chk("Preco ajustado por dentro (5,28%)", r4["apos"]["preco_ajustado"], 2_907_754.86)
chk("BC da CBS/IBS", r4["apos"]["bc_cbs_ibs"], 2_820_522.22)
chk("CBS devida (3,68%)", r4["apos"]["cbs_devida"], 103_795.22)
chk("Ajuste IRPJ/CSLL por dentro", r4["apos"]["ajuste_irpj_csll"], 78.11)
chk("Valor total da NF", r4["apos"]["nf"], 3_016_001.45)
chk("ISS a recolher", r4["apos"]["icms_iss"], 90_480.04)
chk("IRPJ", r4["apos"]["irpj"], 34_932.94)
chk("CSLL", r4["apos"]["csll"], 31_439.64)
chk("CBS a recolher", r4["apos"]["cbs_recolher"], 35_630.17)


print("\n" + "=" * 100)
print("CASO 05 - LUCRO PRESUMIDO, COMERCIO (slides 61 a 67)")
print("=" * 100)

g5 = [Gasto("Despesas", 150_000, "integral"),
      Gasto("Materiais diretos", 1_200_000, "red60", credito_icms=0.12),
      Gasto("Servicos terceiros", 190_000, "red60"),
      Gasto("Aluguel", 120_000, "red70"),
      Gasto("Folha CLT", 720_000, "sem")]
p5 = Parametros(ano=2027, aliq_icms=0.12)
r5 = motor_preco_2026(3_100_000, g5, p5)
chk("Credito de CBS", r5["creditos"]["cbs"], 65_196.83)
chk("Credito de IBS", r5["creditos"]["ibs"], 741.62)
chk("Preco ajustado por dentro (14,28%)", r5["apos"]["preco_ajustado"], 2_891_077.41)
chk("BC da CBS/IBS", r5["apos"]["bc_cbs_ibs"], 2_544_148.12)
chk("Ajuste IRPJ/CSLL por dentro", r5["apos"]["ajuste_irpj_csll"], 858.18)
chk("Valor total da NF", r5["apos"]["nf"], 3_160_805.79)
chk("CBS a recolher", r5["apos"]["cbs_recolher"], 168_864.80)
chk("IBS a recolher", r5["apos"]["ibs_recolher"], 1_802.53)
chk("ICMS a recolher", r5["apos"]["icms_iss"], 235_296.69)
chk("IRPJ", r5["apos"]["irpj"], 35_090.40)
chk("CSLL", r5["apos"]["csll"], 31_581.36)
chk("ICMS a recolher ANTES", r5["antes"]["icms_iss"], 228_000.00)


print("\n" + "=" * 100)
print("CASO 06 - LUCRO PRESUMIDO, INDUSTRIA (slides 69 a 75)")
print("=" * 100)

g6 = [Gasto("Despesas", 150_000, "integral"),
      Gasto("Materiais diretos", 1_200_000, "red60",
            credito_icms=0.12, credito_ipi=0.10),
      Gasto("Servicos terceiros", 190_000, "red60"),
      Gasto("Aluguel", 120_000, "red70"),
      Gasto("Folha CLT", 720_000, "sem")]
p6 = Parametros(ano=2027, aliq_icms=0.12, aliq_ipi=0.10)
r6 = motor_preco_2026(3_100_000, g6, p6)
chk("Preco ajustado por dentro", r6["apos"]["preco_ajustado"], 3_031_068.08)
chk("BC da CBS/IBS", r6["apos"]["bc_cbs_ibs"], 2_667_339.91)
chk("Ajuste IRPJ/CSLL por dentro", r6["apos"]["ajuste_irpj_csll"], 899.73)
chk("Valor total da NF", r6["apos"]["nf"], 3_313_857.14)
chk("CBS a recolher", r6["apos"]["cbs_recolher"], 180_198.45)
chk("ICMS a recolher", r6["apos"]["icms_iss"], 253_662.86)
chk("IRPJ", r6["apos"]["irpj"], 36_789.53)
chk("IPI a recolher ANTES", r6["antes"]["ipi"], 190_000.00)


print("\n" + "=" * 100)
print("CASO 07 - LUCRO REAL, COMERCIO (slides 77 a 82)")
print("=" * 100)

g7 = [Gasto("Despesas", 240_000, "integral"),
      Gasto("Materiais diretos", 900_000, "red60",
            credito_icms=0.12, credito_pis_cofins=True),
      Gasto("Servicos terceiros", 360_000, "red60", credito_pis_cofins=True),
      Gasto("Aluguel", 120_000, "red70", credito_pis_cofins=True),
      Gasto("Folha CLT", 720_000, "sem")]
p7 = Parametros(ano=2027, aliq_icms=0.12)
r7 = motor_preco_2026(3_100_000, g7, p7, lucro_real=True, lucro_liquido=100_000)
chk("PIS a recolher ANTES", r7["antes"]["pis"], 24_974.40)
chk("COFINS a recolher ANTES", r7["antes"]["cofins"], 115_033.60)
chk("ICMS a recolher ANTES", r7["antes"]["icms_iss"], 264_000.00)
chk("Preco ajustado por dentro (12%)", r7["apos"]["preco_ajustado"], 2_862_553.87)
chk("BC da CBS/IBS", r7["apos"]["bc_cbs_ibs"], 2_519_047.41)
chk("Valor total da NF", r7["apos"]["nf"], 3_128_771.38)
chk("CBS a recolher", r7["apos"]["cbs_recolher"], 163_587.31)
chk("IBS a recolher", r7["apos"]["ibs_recolher"], 1_739.50)
chk("ICMS a recolher", r7["apos"]["icms_iss"], 267_452.57)


print("\n" + "=" * 100)
print("LINHA DO TEMPO 2026 a 2033 - mesmo produto (Caso 02, comercio 12% ICMS)")
print("=" * 100)
print(f"  {'Ano':<6}{'CBS':>8}{'IBS':>8}{'ICMS':>8}{'NF':>12}{'vs 2026':>10}")
base = None
for ano in range(2026, 2034):
    pa = Parametros(ano=ano, aliq_icms=0.12, modelo_base="professor", pis=0.0165, cofins=0.076)
    rr = motor_custo(500.0, 0.0986, 0.10, pa)
    if base is None:
        base = rr["nf"]
    al = aliquotas_ano(ano)
    print(f"  {ano:<6}{al['cbs']*100:>7.2f}%{al['ibs']*100:>7.2f}%"
          f"{pa.icms_iss*100:>7.2f}%{rr['nf']:>12,.2f}"
          f"{(rr['nf']/base-1)*100:>9.2f}%")


print("\n" + "=" * 100)
print("ANALISE DE PROPOSTAS DE FORNECEDORES (slides 85 e 86)")
print("=" * 100)
props = [{"nome": "A - Lucro Real", "valor_total": 20_000, "credito_informado": 5_000},
         {"nome": "B - Lucro Presumido", "valor_total": 21_000, "credito_informado": 5_250},
         {"nome": "C - Simples regime regular", "valor_total": 20_500, "credito_informado": 5_125},
         {"nome": "D - Simples tradicional", "valor_total": 17_000, "credito_informado": 570}]
print("  Adquirente CONTRIBUINTE (decide pelo custo real):")
for x in comparar_fornecedores(props, True, Parametros(ano=2027)):
    print(f"    {x['nome']:<30} NF {x['valor_total']:>10,.2f} | "
          f"credito {x['credito']:>9,.2f} | custo real {x['custo_real']:>10,.2f}")
print("  Adquirente NAO CONTRIBUINTE (decide pelo valor final):")
for x in comparar_fornecedores(props, False, Parametros(ano=2027)):
    print(f"    {x['nome']:<30} NF {x['valor_total']:>10,.2f} | "
          f"custo real {x['custo_real']:>10,.2f}")


print("\n" + "=" * 100)
print(f"RESULTADO: {len(OK)} conferem | {len(FALHAS)} divergem")
if FALHAS:
    for f in FALHAS:
        print("  DIVERGE:", f)
print("=" * 100)
