"""
MOTOR DE PRECIFICACAO - REFORMA TRIBUTARIA (LC 214/2025)
Amcont Assessoria & Contabilidade

Nucleo de calculo unico que alimenta a planilha .xlsx e a pagina HTML.
Cobre: Simples Nacional (tradicional x hibrido), Lucro Presumido
(comercio, industria, servicos) e Lucro Real.

Modelos de base de calculo suportados (premissa juridica nao pacificada):
  "professor"  -> BC CBS/IBS = Preco ajustado x (1 - aliq ICMS/ISS).
                  Replica exatamente os slides do curso.
  "lc214"      -> BC CBS/IBS = NF - ICMS/ISS - CBS - IBS.
                  Tecnicamente correto pelo art. 12, par. 2, V e VI da LC 214/2025.
  "plp16"      -> CBS/IBS NAO compoem a base do ICMS/ISS (PLP 16/2025).
"""

from dataclasses import dataclass, field
from typing import List, Literal, Dict


# =============================================================================
# 1. LINHA DO TEMPO DA TRANSICAO (2026 a 2033)
# =============================================================================

# EC 132/2023, art. 128 do ADCT: ICMS e ISS reduzidos em 1/10 ao ano de 2029 a
# 2032; IBS elevado na mesma proporcao. Extincao total em 2033.
CBS_PLENA = 0.093
IBS_PLENO = 0.187

FATOR_IBS = {2026: 0.0, 2027: None, 2028: None,
             2029: 0.10, 2030: 0.20, 2031: 0.30, 2032: 0.40, 2033: 1.00}
FATOR_ICMS_ISS = {2026: 1.00, 2027: 1.00, 2028: 1.00,
                  2029: 0.90, 2030: 0.80, 2031: 0.70, 2032: 0.60, 2033: 0.00}


def aliquotas_ano(ano: int, cbs_plena: float = CBS_PLENA,
                  ibs_pleno: float = IBS_PLENO) -> Dict[str, float]:
    """Aliquotas de CBS e IBS e o fator de reducao de ICMS/ISS no ano."""
    if ano == 2026:
        return {"cbs": 0.0, "ibs": 0.0, "fator_icms_iss": 1.0, "regime": "atual"}
    if ano in (2027, 2028):
        # CBS reduzida em 0,1 p.p. para compensar a aliquota-teste do IBS.
        return {"cbs": cbs_plena - 0.001, "ibs": 0.001,
                "fator_icms_iss": 1.0, "regime": "transicao"}
    if ano not in FATOR_IBS:
        raise ValueError(f"Ano {ano} fora do intervalo 2026-2033.")
    return {"cbs": cbs_plena,
            "ibs": ibs_pleno * FATOR_IBS[ano],
            "fator_icms_iss": FATOR_ICMS_ISS[ano],
            "regime": "rampa" if ano < 2033 else "pleno"}


# =============================================================================
# 2. ESTRUTURAS DE ENTRADA
# =============================================================================

REDUCOES = {"integral": 0.00, "red30": 0.30, "red60": 0.60,
            "red70": 0.70, "sem": 1.00}

# Presuncoes de IRPJ e CSLL por atividade (arts. 15 e 20 da Lei 9.249/1995).
# Servicos hospitalares e equiparados usam 8% e 12% desde que a empresa seja
# sociedade empresaria e atenda as normas da Anvisa.
ATIVIDADES = {
    "comercio":    {"imposto": "ICMS", "ipi": False, "irpj": 0.08,  "csll": 0.12},
    "industria":   {"imposto": "ICMS", "ipi": True,  "irpj": 0.08,  "csll": 0.12},
    "carga":       {"imposto": "ICMS", "ipi": False, "irpj": 0.08,  "csll": 0.12},
    "passageiros": {"imposto": "ICMS", "ipi": False, "irpj": 0.16,  "csll": 0.12},
    "servicos":    {"imposto": "ISS",  "ipi": False, "irpj": 0.32,  "csll": 0.32},
    "hospitalar":  {"imposto": "ISS",  "ipi": False, "irpj": 0.08,  "csll": 0.12},
    "combustivel": {"imposto": "ICMS", "ipi": False, "irpj": 0.016, "csll": 0.12},
}

LIMITE_ADICIONAL = 240_000.0          # R$ 20.000 por mes, art. 3 da Lei 9.249/1995
ALIQ_ADICIONAL = 0.10


def adicional_irpj(base: float) -> float:
    """Adicional de 10% sobre a parcela da base que excede R$ 240.000 no ano."""
    return max(0.0, base - LIMITE_ADICIONAL) * ALIQ_ADICIONAL


@dataclass
class Gasto:
    """Linha de custo ou despesa do cliente."""
    descricao: str
    valor: float                       # valor bruto pago ao fornecedor
    reducao_cbs_ibs: str = "integral"  # chave de REDUCOES
    credito_icms: float = 0.0          # aliquota de ICMS creditavel (0 se nao gera)
    credito_ipi: float = 0.0           # aliquota de IPI creditavel
    credito_pis_cofins: bool = False   # apenas Lucro Real, cenario "antes"

    def aliq_efetiva(self, aliq_base: float) -> float:
        return aliq_base * (1 - REDUCOES[self.reducao_cbs_ibs])


@dataclass
class Parametros:
    ano: int = 2027
    modelo_base: Literal["professor", "lc214", "plp16"] = "professor"
    gross_up_credito: Literal["separado", "conjunto"] = "separado"
    cbs_plena: float = CBS_PLENA
    ibs_pleno: float = IBS_PLENO
    # Saida
    aliq_icms: float = 0.12
    aliq_iss: float = 0.0
    aliq_ipi: float = 0.0
    reducao_saida: str = "integral"   # reducao setorial na CBS/IBS de saida
    # Regime atual (cenario "antes")
    pis: float = 0.0065
    cofins: float = 0.03
    # IRPJ / CSLL
    presuncao_irpj: float = 0.08
    presuncao_csll: float = 0.12
    aliq_irpj: float = 0.15
    aliq_csll: float = 0.09

    @property
    def cbs(self) -> float:
        a = aliquotas_ano(self.ano, self.cbs_plena, self.ibs_pleno)
        return a["cbs"] * (1 - REDUCOES[self.reducao_saida])

    @property
    def ibs(self) -> float:
        a = aliquotas_ano(self.ano, self.cbs_plena, self.ibs_pleno)
        return a["ibs"] * (1 - REDUCOES[self.reducao_saida])

    @property
    def icms_iss(self) -> float:
        """Aliquota vigente de ICMS ou ISS no ano, ja com a rampa de reducao."""
        f = aliquotas_ano(self.ano, self.cbs_plena, self.ibs_pleno)["fator_icms_iss"]
        return (self.aliq_icms + self.aliq_iss) * f

    @property
    def t_irpj_csll_receita(self) -> float:
        """Carga de IRPJ+CSLL como percentual da receita (Lucro Presumido)."""
        return (self.presuncao_irpj * self.aliq_irpj
                + self.presuncao_csll * self.aliq_csll)


# =============================================================================
# 3. APROPRIACAO DE CREDITOS
# =============================================================================

def creditos_cbs_ibs(gastos: List[Gasto], p: Parametros) -> Dict[str, float]:
    """Credito de CBS e IBS a apropriar, com gross-up da base."""
    tot_cbs = tot_ibs = 0.0
    detalhe = []
    a = aliquotas_ano(p.ano, p.cbs_plena, p.ibs_pleno)
    for g in gastos:
        ac = a["cbs"] * (1 - REDUCOES[g.reducao_cbs_ibs])
        ai = a["ibs"] * (1 - REDUCOES[g.reducao_cbs_ibs])
        if p.gross_up_credito == "separado":
            bc_c = g.valor / (1 + ac) if ac else g.valor
            bc_i = g.valor / (1 + ai) if ai else g.valor
        else:  # conjunto: art. 12 par. 2 - nenhum dos dois integra a base
            div = 1 + ac + ai
            bc_c = bc_i = g.valor / div if div > 1 else g.valor
        c, i = bc_c * ac, bc_i * ai
        tot_cbs += c
        tot_ibs += i
        detalhe.append({"descricao": g.descricao, "valor": g.valor,
                        "bc_cbs": bc_c, "aliq_cbs": ac, "credito_cbs": c,
                        "bc_ibs": bc_i, "aliq_ibs": ai, "credito_ibs": i})
    return {"cbs": tot_cbs, "ibs": tot_ibs, "total": tot_cbs + tot_ibs,
            "detalhe": detalhe}


# =============================================================================
# 4. MOTOR A - PRECIFICACAO A PARTIR DO CUSTO (MARK UP)
# =============================================================================

def motor_custo(custo: float, pct_despesas: float, pct_lucro: float,
                p: Parametros) -> Dict:
    """
    Preco de venda a partir do custo liquido de creditos.
    'pct_despesas' e 'pct_lucro' sao percentuais sobre a receita liquida
    (preco antes dos tributos sobre vendas), como no material do curso.
    """
    p0 = custo / (1 - pct_despesas - pct_lucro)
    i, c, b = p.icms_iss, p.cbs, p.ibs

    if p.ano == 2026:
        # PIS/COFINS cumulativos com exclusao do ICMS da base.
        t_pc = (p.pis + p.cofins) * (1 - i)
        nf = p0 / (1 - i - t_pc)
        icms = nf * i
        return {"preco_antes_tributos": p0, "nf": nf, "icms_iss": icms,
                "cbs": 0.0, "ibs": 0.0,
                "pis": (nf - icms) * p.pis, "cofins": (nf - icms) * p.cofins,
                "markup_total": nf / custo}

    if p.modelo_base == "professor":
        # BC da CBS/IBS = NF - ICMS (CBS e IBS permanecem na propria base).
        nf = p0 / ((1 - i) * (1 - (c + b)))
        bc = nf * (1 - i)
    elif p.modelo_base == "lc214":
        # BC da CBS/IBS = NF - ICMS - CBS - IBS.
        nf = p0 / (1 - i - (c + b) * (1 - i) / (1 + c + b))
        bc = nf * (1 - i) / (1 + c + b)
    else:  # plp16 - CBS/IBS fora da base do ICMS/ISS
        v_op = p0 / (1 - i)
        bc = v_op * (1 - i)
        nf = v_op + bc * (c + b)

    icms = (nf if p.modelo_base != "plp16" else nf - bc * (c + b)) * i
    return {"preco_antes_tributos": p0, "nf": nf, "bc_cbs_ibs": bc,
            "icms_iss": icms, "cbs": bc * c, "ibs": bc * b,
            "pis": 0.0, "cofins": 0.0, "markup_total": nf / custo}


# =============================================================================
# 5. MOTOR B - PRECIFICACAO A PARTIR DO PRECO DE 2026 (MANTEM O LIQUIDO)
# =============================================================================

def motor_preco_2026(receita_bruta: float, gastos: List[Gasto], p: Parametros,
                     lucro_real: bool = False,
                     lucro_liquido: float = 0.0) -> Dict:
    """
    Recalcula o preco de 2027+ preservando a receita liquida de tributos de 2026.
    Replica o metodo sequencial dos casos praticos 04 a 07.
    """
    a26 = Parametros(**{**p.__dict__, "ano": 2026})

    # ---------- Cenario ANTES (2026) ----------
    if lucro_real:
        pis_dev = (receita_bruta - receita_bruta * p.aliq_icms) * 0.0165
        cof_dev = (receita_bruta - receita_bruta * p.aliq_icms) * 0.076
        # Lei 14.592/2023: o ICMS nao integra a base do credito de PIS/COFINS.
        bc_pc = sum(g.valor * (1 - p.aliq_icms)
                    for g in gastos if g.credito_pis_cofins)
        cred_pis, cred_cof = bc_pc * 0.0165, bc_pc * 0.076
        base_irpj_ant = lucro_liquido
        base_csll_ant = lucro_liquido
    else:
        pis_dev = receita_bruta * p.pis
        cof_dev = receita_bruta * p.cofins
        cred_pis = cred_cof = 0.0
        base_irpj_ant = receita_bruta * p.presuncao_irpj
        base_csll_ant = receita_bruta * p.presuncao_csll
    irpj_ant = base_irpj_ant * p.aliq_irpj
    adic_ant = adicional_irpj(base_irpj_ant)
    csll_ant = base_csll_ant * p.aliq_csll

    ipi_dev = receita_bruta * p.aliq_ipi
    ipi_cred = sum(g.valor * g.credito_ipi for g in gastos)
    icms_dev_ant = receita_bruta * (p.aliq_icms + p.aliq_iss)
    # O ISS e cumulativo e nao gera credito na entrada. So o ICMS gera.
    icms_cred = (sum(g.valor * g.credito_icms for g in gastos)
                 if p.aliq_icms > 0 else 0.0)

    # No Lucro Real o IRPJ/CSLL incide sobre lucro fixo: e identico nos dois
    # cenarios e por isso nao entra no alvo de receita liquida.
    liquido_alvo = receita_bruta - pis_dev - cof_dev - icms_dev_ant
    if not lucro_real:
        liquido_alvo -= (irpj_ant + adic_ant + csll_ant)

    # ---------- Cenario APOS ----------
    cr = creditos_cbs_ibs(gastos, p)
    base = liquido_alvo + (ipi_cred if p.aliq_ipi else 0.0) \
        + cred_pis + cred_cof - cr["total"]

    i = p.icms_iss
    c, b = p.cbs, p.ibs
    fator = aliquotas_ano(p.ano, p.cbs_plena, p.ibs_pleno)["fator_icms_iss"]

    # O adicional de IRPJ so incide acima de R$ 240.000, o que cria um degrau
    # na equacao dos tributos por dentro. As duas hipoteses sao calculadas em
    # forma fechada e a coerente e adotada. Mesmo algoritmo da planilha.
    r_base = 0.0 if lucro_real else p.t_irpj_csll_receita

    liquido_antes = (receita_bruta + ipi_dev - ipi_cred) - (
        (pis_dev - cred_pis) + (cof_dev - cred_cof) + (icms_dev_ant - icms_cred)
        + (ipi_dev - ipi_cred) + irpj_ant + adic_ant + csll_ant)

    base0 = liquido_antes - icms_cred + (ipi_cred if p.aliq_ipi else 0.0) - cr["total"]

    def hipotese(com_adicional: bool):
        r_ = r_base + (p.presuncao_irpj * ALIQ_ADICIONAL
                       if (com_adicional and not lucro_real) else 0.0)
        base_ = base0 - (LIMITE_ADICIONAL * ALIQ_ADICIONAL
                         if (com_adicional and not lucro_real) else 0.0)
        A = base_ / (1 - i - r_)
        bc_ = A * (1 - i) / (1 + c + b) if p.modelo_base == "lc214" else A * (1 - i)
        cbs_d, ibs_d = bc_ * c, bc_ * b
        cbs_nf = cbs_d if p.modelo_base == "plp16" else cbs_d / (1 - i)
        ibs_nf = ibs_d if p.modelo_base == "plp16" else ibs_d / (1 - i)
        k = r_ / (1 - i)
        nf_ = (A + cbs_nf + ibs_nf - k * (cbs_d + ibs_d + A)) / (1 - k)
        bl = nf_ - cbs_d - ibs_d
        b_irpj = lucro_liquido if lucro_real else bl * p.presuncao_irpj
        return {"nf": nf_, "A": A, "bc": bc_, "cbs_d": cbs_d, "ibs_d": ibs_d,
                "cbs_nf": cbs_nf, "ibs_nf": ibs_nf, "bl": bl, "b_irpj": b_irpj}

    h1 = hipotese(False)
    res = h1 if (lucro_real or h1["b_irpj"] <= LIMITE_ADICIONAL) else hipotese(True)
    hipotese_adotada = 1 if res is h1 else 2

    base_imp = (res["nf"] - res["cbs_nf"] - res["ibs_nf"]) \
        if p.modelo_base == "plp16" else res["nf"]
    imp_d = base_imp * (p.aliq_icms + p.aliq_iss) * fator
    b_csll = lucro_liquido if lucro_real else res["bl"] * p.presuncao_csll
    irpj_ = res["b_irpj"] * p.aliq_irpj
    adic_ = adicional_irpj(res["b_irpj"])
    csll_ = b_csll * p.aliq_csll
    trib = ((res["cbs_d"] - cr["cbs"]) + (res["ibs_d"] - cr["ibs"])
            + (imp_d - icms_cred) + irpj_ + adic_ + csll_)
    res.update({"preco_ajustado": res["A"], "imp_d": imp_d, "irpj": irpj_,
                "adic": adic_, "csll": csll_, "trib": trib,
                "liquido": res["nf"] - trib})
    base = base0

    preco_ajustado = res["preco_ajustado"]
    bc = res["bc"]
    cbs_dev, ibs_dev = res["cbs_d"], res["ibs_d"]
    nf = res["nf"]
    ajuste = nf - preco_ajustado - res["cbs_d"] - res["ibs_d"]
    icms_dev_pos = res["imp_d"]
    base_lucro = nf - cbs_dev - ibs_dev
    irpj_pos, adic_pos, csll_pos = res["irpj"], res["adic"], res["csll"]

    return {
        "antes": {"nf": receita_bruta + ipi_dev - ipi_cred, "pis": pis_dev - cred_pis,
                  "cofins": cof_dev - cred_cof,
                  "icms_iss": icms_dev_ant - icms_cred,
                  "ipi": ipi_dev - ipi_cred, "irpj": irpj_ant,
                  "adicional_irpj": adic_ant, "csll": csll_ant,
                  "liquido": liquido_antes},
        "apos": {"nf": nf, "preco_ajustado": preco_ajustado, "bc_cbs_ibs": bc,
                 "cbs_devida": cbs_dev, "ibs_devida": ibs_dev,
                 "cbs_recolher": cbs_dev - cr["cbs"],
                 "ibs_recolher": ibs_dev - cr["ibs"],
                 "icms_iss": icms_dev_pos - icms_cred,
                 "ipi": 0.0, "irpj": irpj_pos, "adicional_irpj": adic_pos,
                 "csll": csll_pos, "ajuste_irpj_csll": ajuste,
                 "liquido": res["liquido"], "total_tributos": res["trib"],
                 "hipotese_adicional": hipotese_adotada},
        "creditos": cr, "liquido_alvo": liquido_alvo,
    }


# =============================================================================
# 6. MOTOR C - SIMPLES NACIONAL: TRADICIONAL x HIBRIDO
# =============================================================================

@dataclass
class RepartDAS:
    """Reparticao da aliquota efetiva do DAS por tributo (LC 123, anexos)."""
    irpj: float = 0.0
    csll: float = 0.0
    cofins: float = 0.0
    pis: float = 0.0
    cpp: float = 0.0
    ipi: float = 0.0
    icms: float = 0.0
    iss: float = 0.0

    @property
    def total(self) -> float:
        return sum([self.irpj, self.csll, self.cofins, self.pis,
                    self.cpp, self.ipi, self.icms, self.iss])

    @property
    def hibrida(self) -> float:
        """Aliquota do DAS sem PIS e COFINS (substituidos por CBS/IBS)."""
        return self.total - self.pis - self.cofins


def _simples_nucleo(receita: float, rep: RepartDAS, base_credito_compras: float,
                    base_credito_despesas: float, p: Parametros) -> Dict:
    """Compara Simples tradicional com Simples optante do regime regular."""
    das_trad = receita * rep.total
    liquido = receita - das_trad

    cbs_comp = base_credito_compras * p.cbs
    ibs_comp = base_credito_compras * p.ibs
    cbs_desp = base_credito_despesas * p.cbs
    ibs_desp = base_credito_despesas * p.ibs
    cred = cbs_comp + ibs_comp + cbs_desp + ibs_desp

    # Preco sem CBS/IBS que preserva o liquido, ja descontados os creditos.
    preco_hib = (liquido - cred) / (1 - rep.hibrida)
    das_hib = preco_hib * rep.hibrida

    # BC da CBS/IBS exclui as parcelas de CPP, IPI, ICMS e ISS contidas no DAS
    # (art. 12, par. 2, V e VI da LC 214/2025). IRPJ e CSLL permanecem.
    bc = preco_hib * (1 - rep.cpp - rep.ipi - rep.icms - rep.iss)
    cbs_dev, ibs_dev = bc * p.cbs, bc * p.ibs
    cbs_rec = cbs_dev - cbs_comp - cbs_desp
    ibs_rec = ibs_dev - ibs_comp - ibs_desp
    nf = preco_hib + cbs_dev + ibs_dev

    carga_trad, carga_hib = das_trad, das_hib + cbs_rec + ibs_rec
    return {
        "tradicional": {"nf": receita, "das": das_trad, "liquido": liquido,
                        "carga": carga_trad},
        "hibrido": {"nf": nf, "preco_sem_cbs_ibs": preco_hib, "das": das_hib,
                    "bc_cbs_ibs": bc, "cbs_devida": cbs_dev, "ibs_devida": ibs_dev,
                    "cbs_recolher": cbs_rec, "ibs_recolher": ibs_rec,
                    "liquido": preco_hib - das_hib + cred, "carga": carga_hib},
        "creditos": cred,
        "delta_carga": carga_trad - carga_hib,
        "delta_pct": (carga_trad - carga_hib) / carga_trad if carga_trad else 0,
    }


def _credito_equilibrio(receita: float, rep: RepartDAS, p: Parametros) -> float:
    """Base de compras creditavel que iguala as duas cargas tributarias."""
    lo, hi = 0.0, receita * 5
    for _ in range(100):
        mid = (lo + hi) / 2
        if _simples_nucleo(receita, rep, mid, 0.0, p)["delta_carga"] < 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def motor_simples(receita: float, rep: RepartDAS, base_credito_compras: float,
                  base_credito_despesas: float, p: Parametros) -> Dict:
    """Simples tradicional x hibrido, com o ponto de equilibrio de creditos."""
    r = _simples_nucleo(receita, rep, base_credito_compras,
                        base_credito_despesas, p)
    r["credito_equilibrio"] = _credito_equilibrio(receita, rep, p)
    return r


# =============================================================================
# 7. ANALISE DE PROPOSTAS DE FORNECEDORES
# =============================================================================

def comparar_fornecedores(propostas: List[Dict], adquirente_contribuinte: bool,
                          p: Parametros) -> List[Dict]:
    """
    Cada proposta: {"nome", "valor_total", "reducao" (chave de REDUCOES),
                    "simples_tradicional": bool, "credito_informado": float|None}
    Contribuinte do regime regular decide pelo custo liquido de creditos;
    nao contribuinte decide pelo valor final da nota.
    """
    out = []
    for pr in propostas:
        if pr.get("credito_informado") is not None:
            cred = pr["credito_informado"]
        elif pr.get("simples_tradicional"):
            cred = 0.0
        else:
            red = REDUCOES[pr.get("reducao", "integral")]
            aliq = (p.cbs + p.ibs) * (1 - red)
            cred = pr["valor_total"] / (1 + aliq) * aliq
        custo = pr["valor_total"] - (cred if adquirente_contribuinte else 0.0)
        out.append({"nome": pr["nome"], "valor_total": pr["valor_total"],
                    "credito": cred, "custo_real": custo})
    return sorted(out, key=lambda x: x["custo_real"])
